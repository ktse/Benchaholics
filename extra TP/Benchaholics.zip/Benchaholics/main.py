from data import *
from flask import Flask, render_template, request, redirect, url_for
users = []
curName = []
# app configuration
app = Flask(__name__)
app.debug = True
#helper functions
@app.route("/")
def home():
  return render_template("index.html")

@app.route("/login", methods = ["POST"])
def login():
  return render_template("register.html")

@app.route("/newUser", methods = ["POST"])
def createUser():
  name = request.form["name"]
  gender = request.form["gender"]
  users.append(User(name,gender))
  curName.append(name)
  print("cur",curName)
  # for user in users:
  #   print(user)
  return redirect(url_for("inputWeight"))

@app.route("/newEntry", methods = ["POST"])
def createEntry():
  movement = request.form["movement"]
  date = request.form["date"]
  weight = request.form["weight"]
  sets = request.form["sets"]
  reps = request.form["reps"]
  for user in users:
    if user.getName() == curName[-1]:
      if movement == "1":
        user.addBench(date,weight,sets,reps)
      elif movement == "2":
        user.addSquat(date,weight,sets,reps)
      else:
        user.addDeadlift(date,weight,sets,reps)
  for user in users:
    print(user.benchPress)
  return render_template("stats.html")

@app.route("/inputWeight")
def inputWeight():
  return render_template("InputWeight.html")

@app.route("/callData", methods = ["GET"])
def getBenchData():
  users = create()
  return users


# actual calls
if __name__ == "__main__":
  app.run()