class User (object):
	def __init__(self,name,gender):
		self.name = name
		if gender == "1":
			self.gender = "Male"
		else:
			self.gender = "Female"
		self.benchPress = dict()
		self.squat = dict()
		self.deadlift = dict()
	def addBench(self,date,weight,sets,reps):
		self.benchPress[date] = (weight,sets,reps)
	def addSquat(self,date,weight,sets,reps):
		self.squat[date] = (weight,sets,reps)
	def addDeadlift(self,date,weight,sets,reps):
		self.deadlift[date] = (weight,sets,reps)
	def getName(self):
		return self.name
	def __str__(self):
		return "%s , %s" %(self.name,self.gender)

class Weight (object):
	def __init__(self,weight,sets,reps):
		self.weight = weight
		self.sets = sets
		self.reps = reps
	def returnTupleData(self):
		return [self.weight,(self.sets,self.reps)]
	def getWeight(self):
		return Weight
	def getSetsReps(self):
		return (self.sets,self.reps)
