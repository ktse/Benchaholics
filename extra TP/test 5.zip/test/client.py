import socket
from _thread import *
from queue import Queue
from tkinter import *
import string
import pickle
import math

HOST = ''
PORT = 6702

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 

server.connect((HOST,PORT))
print("connected to server")


class User(object):
    def __init__(self, id, elements):
        self.id = id
        self.elements = elements # elements is elements placed, use a dict sync with others instead of a billion strings

class Selector(object):
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.top = self.y - self.height
        self.left = self.x - self.width
        self.right = self.x + self.width
        self.bottom = self.y + self.height

    def __repr__(self):
        return 'Selector %d %d %d %d' % (self.x, self.y, self.width, self.height)

class TextBox(Selector): # round the corners for buttons
    def __init__(self, x, y, width, height, color, text):
        super().__init__(x, y, width, height, color)
        self.top = self.y - self.height
        self.left = self.x - self.width
        self.right = self.x + self.width
        self.bottom = self.y + self.height
        self.text = text
        self.type = 'textBox'
        self.fontSize = '14'

    def draw(self, canvas, xOffset=0):
        canvas.create_polygon((self.left + xOffset, self.top), (self.right + xOffset, self.top), (self.right + xOffset, self.bottom),(self.left + xOffset, self.bottom), fill=self.color, outline = 'black')
        canvas.create_text(self.x + xOffset, self.y, text = self.text, font = 'Helvetica ' + self.fontSize)
        # canvas.create_text(cx, cy, text = self.text, anchor=anchor)

class Buttonn(TextBox):
    def __init__(self, x, y, width, height, color, text):
        super().__init__(x, y, width, height, color, text)
        self.type = 'button'
        self.linkedTo = None

    def draw(self, canvas, xOffset=0):
        canvas.create_polygon((self.left + xOffset, self.top + 8), (self.left + 1 + xOffset, self.top + 4.5), (self.left + 2 + xOffset, self.top + 3), (self.left + 4.5 + xOffset, self.top + 1), (self.left + 8 + xOffset, self.top),
            (self.right - 8 + xOffset, self.top), (self.right - 5 + xOffset, self.top + 1), (self.right - 2 + xOffset, self.top + 3), (self.right - 1 + xOffset, self.top + 4.5), (self.right + xOffset, self.top + 8), 
            (self.right + xOffset, self.bottom - 8),(self.right - 1 + xOffset, self.bottom - 4.5),(self.right - 2 + xOffset, self.bottom - 3),(self.right - 4 + xOffset, self.bottom - 1),(self.right - 8 + xOffset, self.bottom),
            (self.left + 8 + xOffset, self.bottom), (self.left + 4.5 + xOffset, self.bottom - 1), (self.left + 2 + xOffset, self.bottom - 3), (self.left + 1 + xOffset, self.bottom - 4), (self.left + xOffset, self.bottom - 8),
            fill=self.color, outline = 'black')
        canvas.create_text(self.x + xOffset, self.y, text = self.text)

class Slider(Selector):
    def __init__(self, x, y, width, height, color, radius):
        super().__init__(x, y, width, height, color)
        self.r = radius
        self.type = 'slider'
        self.cx = self.x # have centers for circle independent of the rectangle
        self.cy = self.y

    def draw(self, canvas, xOffset=0):
        canvas.create_polygon((self.left + xOffset, self.top), (self.right + xOffset, self.top), (self.right + xOffset, self.bottom),(self.left + xOffset, self.bottom), fill=self.color, outline = 'black')
        canvas.create_oval(self.cx - self.r + xOffset, self.cy - self.r, self.cx + self.r + xOffset, self.cy + self.r, fill=self.color)

class DropDown(TextBox):
    def __init__(self, x, y, width, height, color, text):
        super().__init__(x, y, width, height, color, text)
        self.type = 'dropdown'
        self.opened = False
        self.text = text
        self.shownText = text

    def draw(self, canvas, xOffset=0):
        canvas.create_polygon((self.left + xOffset, self.top), (self.right + xOffset, self.top), (self.right + xOffset, self.bottom),(self.left + xOffset, self.bottom), fill=self.color, outline = 'black')
        canvas.create_line(self.right - 20 + xOffset, self.top, self.right + xOffset - 20, self.bottom)
        canvas.create_polygon(self.right + xOffset - 18, self.top + 12, self.right + xOffset - 2, self.top + 12, self.right + xOffset - 10, self.bottom - 8, fill=self.color, outline='black')
        canvas.create_text(self.x + xOffset, self.y, text=self.shownText)

class AnimatedBox(Selector): 
    def draw(self, canvas):
        canvas.create_rectangle(self.x - self.width, self.y - self.height, self.x + self.width, self.y + self.height, fill=self.color)

def keyPressed(event, data):
    # use event.x and event.y
    if data.mode == "editing":
        editingKeyPressed(event,data)
    elif data.mode == "testing":
        testingKeyPressed(event,data)
    elif data.mode == 'login':
        loginKeyPressed(event, data)
    elif data.mode == 'signup':
        signupKeyPressed(event, data)

def timerFired(data):
    if data.mode == "editing":
        editingTimerFired(data)
    elif data.mode == "testing":
        testingTimerFired(data)
    elif data.mode == 'login':
        loginTimerFired(data)
    elif data.mode == 'signup':
        signupTimerFired(data)

def redrawAll(canvas, data):
    if data.mode == "editing":
        editingRedrawAll(canvas,data)
    elif data.mode == "testing":
        testingRedrawAll(canvas,data)
    elif data.mode == 'login':
        loginRedrawAll(canvas, data)
    elif data.mode == 'signup':
        signupRedrawAll(canvas, data)

def leftMousePressed(event, data):
    if data.mode == "editing":
        editingLeftMousePressed(event,data)
    elif data.mode == "testing":
        testingLeftMousePressed(event,data)
    elif data.mode == 'login':
        loginLeftMousePressed(event, data)
    elif data.mode == 'signup':
        signupLeftMousePressed(event, data)

def leftMouseMoved(event, data):
    if data.mode == "editing":
        editingLeftMouseMoved(event,data)
    elif data.mode == "testing":
        testingLeftMouseMoved(event,data)
    elif data.mode == 'login':
        loginLeftMouseMoved(event, data)
    elif data.mode == 'signup':
        signupLeftMouseMoved(event, data)

def leftMouseReleased(event, data):
    if data.mode == "editing":
        editingLeftMouseReleased(event,data)
    elif data.mode == "testing":
        testingLeftMouseReleased(event,data)
    elif data.mode == 'login':
        loginLeftMouseReleased(event, data)
    elif data.mode == 'signup':
        signupLeftMouseReleased(event, data)

def init(data):
    data.width = 1000
    data.height = 700
    data.margin = 10

    data.texts = {}
    data.phoneImage = PhotoImage(file='iphone.gif')
    data.save = PhotoImage(file='save.gif')
    data.load = PhotoImage(file='load.gif')
    # data.clear = PhotoImage(file='clear.gif')

    # data.clearBounds = (660, 0, 710, 50)
    data.saveBounds = (740, 0, 790, 50)
    data.loadBounds = (820, 0, 870, 50)

    data.mode = 'editing'
    data.checkFunction = None
    data.otherUsers = []
    data.elementsPlaced = {'0':[], '1':[], '2':[], '3':[], '4':[], '5':[]}

    data.iphone6Res = (337.5, 580.3)

    button = (0, 50, 100, 150, "button")
    slider = (0, 150, 100, 250, "slider")
    textBox = (0, 250, 100, 350, "textBox")
    dropDown = (0, 350, 100, 450, "dropDown")
    lineTool = (0, 450, 100, 550, "line tool")
    color = (0, 550, 100, 650, "color")
    data.elementBoxes = [button, slider, textBox, dropDown, lineTool, color]

    s1 = (900, 50, 1050, 150, '0')
    s2 = (900, 150, 1050, 250, '1')
    s3 = (900, 250, 1050, 350, '2')
    s4 = (900, 350, 1050, 450, '3')
    s5 = (900, 450, 1050, 550, '4')
    s6 = (900, 550, 1050, 650, '5')

    data.screenButtons = [s1, s2, s3, s4, s5, s6]

    data.elementHeld = None
    data.currentHeld = None
    data.editing = False
    data.editArea = None

    data.chooseColor = False
    data.grabberSize = 4
    data.firstBox = [135, 160, 298, 230]
    optionsBox = [135, 160, 298, 338,'']
    data.dropDownOptions = [135, 160, 298, 338]
    data.dropDownOptionsWidth = 1
    data.secondBox = [135, 260, 298, 330]

    data.firstBoxWidth = 1
    data.secondBoxWidth = 1

    data.currentScreen = '0'
    data.currentElement = None

    data.titleText = ''
    data.screenSelect = False

    data.fontInput = [255, 135, 285, 165]
    data.fontInputWidth = 1

    data.timer = 0
    data.firstClick = None
    data.secondClick = None

    data.editedText = None
    data.optionBoxes = {'0':[], '1':[], '2':[], '3':[], '4':[], '5':[]}

    data.me = User(0, data.elementsPlaced)


    data.colorBox = AnimatedBox(-100, 600, 175, 50, 'white')

    data.colorChoices = [(115, 560, 150.0, 595.0, 'red'), 
                        (168, 560, 203.0, 595.0, 'orange'), 
                        (221, 560, 256.0, 595.0, 'yellow'), 
                        (274, 560, 309.0, 595.0, 'green'), 
                        (327, 560, 362.0, 595.0, 'blue'), 
                        (115, 608, 150.0, 643.0, 'purple'), 
                        (168, 608, 203.0, 643.0, 'pink'), 
                        (221, 608, 256.0, 643.0, 'brown'), 
                        (274, 608, 309.0, 643.0, 'white'), 
                        (327, 608, 362.0, 643.0, 'black')]
    data.offset = 337.5
    data.screenTransition = None
    data.movingCircle = None

    data.usernameInput, data.usernameInputWidth = (400, 350, 600, 390), 1
    data.passwordInput, data.passwordInputWidth = (400, 440, 600, 480), 1
    data.username, data.password = '', ''

    data.loginButton = data.signupButton = (380, 520, 620, 570)
    data.startSignUp = (455, 590, 545, 630)

    try:
        data.userInformation = pickle.load(open("userInfo.p", "rb"))
    except:
        data.userInformation = {}
    # data.clearConfirmation = False

    data.xDifference, data.yDifference = None, None

    data.screenText = (450, 650, 550, 700)
    data.screenName = {'0':'Screen 0', '1':'Screen 1', '2':'Screen 2', '3':'Screen 3', '4':'Screen 4', '5':'Screen 5'}

def loginMousePressed(event, data):
    pass

def loginKeyPressed(event, data):
    if event.keysym == 'Return':
        userInfo = pickle.load(open("userInfo.p", "rb"))
        if data.username in userInfo and userInfo[data.username] == data.password:
            data.mode = 'editing'
    if data.usernameInputWidth == 4: #meaning that the user is currently inputting his/her username
        if event.keysym in string.printable:
            data.username += event.keysym
        elif event.keysym == 'BackSpace':
            data.username = data.username[:-1]
    elif data.passwordInputWidth == 4:
        if event.keysym in string.printable:
            data.password += event.keysym
        elif event.keysym == 'BackSpace':
            data.password = data.password[:-1]

def loginTimerFired(data):
    pass

def loginRedrawAll(canvas, data):
    canvas.create_text(500, 250, text='Login', font='Helvetica 40')
    canvas.create_text(500, 330, text="Username", font='Helvetica 30')
    canvas.create_rectangle(data.usernameInput, width=data.usernameInputWidth)
    canvas.create_text(410, 370, text=data.username, font='Helvetica 25', anchor=W)


    canvas.create_text(500, 420, text="Password", font='Helvetica 30')
    canvas.create_rectangle(data.passwordInput, width=data.passwordInputWidth)
    canvas.create_text(410, 460, text=data.password, font='Helvetica 25', anchor = W)

    canvas.create_text(500, 600, text="Don't have an account?", font='Helvetica 15')
    canvas.create_text(500, 620, text="Sign up now!", font='Helvetica 15', fill='blue')

    canvas.create_text(500, 545, text="Log In", font='Helvetica 30')
    canvas.create_rectangle(data.loginButton)

def loginLeftMousePressed(event, data):
    if clickedInBounds(event.x, event.y, data.usernameInput):
        data.usernameInputWidth = 4
        data.passwordInputWidth = 1
    elif clickedInBounds(event.x, event.y, data.passwordInput):
        data.usernameInputWidth = 1
        data.passwordInputWidth = 4
    elif clickedInBounds(event.x, event.y, data.startSignUp):
        data.mode = 'signup'
        data.usernameInputWidth = 1
        data.passwordInputWidth = 1  
        data.username = data.password = ''
    elif clickedInBounds(event.x, event.y, data.loginButton):
        userInfo = pickle.load(open("userInfo.p", "rb"))
        if data.username in userInfo and userInfo[data.username] == data.password:
            data.mode = 'editing'
    else:
        data.usernameInputWidth = 1
        data.passwordInputWidth = 1  

def loginLeftMouseMoved(event, data):
    pass    

def loginLeftMouseReleased(event, data):
    pass


# def readFile(path): # used from string notes https://www.cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO
#     with open(path, "rt") as f:
#         return f.read()

# def writeFile(path, contents): # used from string notes https://www.cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO
#     with open(path, "wt") as f:
#         f.write(contents)

def signupKeyPressed(event, data):
    if event.keysym == 'Return' and data.password != '' and data.username != '':
        data.mode = 'login'
        data.usernameInputWidth = 1
        data.passwordInputWidth = 1  
        data.userInformation[data.username] = data.password
        data.username = data.password = ''
        pickle.dump(data.userInformation, open('userInfo.p', 'wb'))
    if data.usernameInputWidth == 4: # meaning that the user is currently inputting his/her username
        if event.keysym in string.printable:
            data.username += event.keysym
        elif event.keysym == 'BackSpace':
            data.username = data.username[:-1]

    elif data.passwordInputWidth == 4:
        if event.keysym in string.printable:
            data.password += event.keysym
        elif event.keysym == 'BackSpace':
            data.password = data.password[:-1]
   

def signupTimerFired(data):
    pass

def signupRedrawAll(canvas, data):
    canvas.create_text(500, 250, text='Sign Up', font='Helvetica 40')
    canvas.create_text(500, 330, text="Create Username", font='Helvetica 30')
    canvas.create_rectangle(data.usernameInput, width=data.usernameInputWidth)
    canvas.create_text(410, 370, text=data.username, font='Helvetica 25', anchor=W)


    canvas.create_text(500, 420, text="Create Password", font='Helvetica 30')
    canvas.create_rectangle(data.passwordInput, width=data.passwordInputWidth)
    canvas.create_text(410, 460, text=data.password, font='Helvetica 25', anchor = W)

    canvas.create_text(500, 545, text="Sign Up", font='Helvetica 30')
    canvas.create_rectangle(data.signupButton)


def signupLeftMousePressed(event, data):
    print(data.userInformation)
    if clickedInBounds(event.x, event.y, data.usernameInput):
        data.usernameInputWidth = 4
        data.passwordInputWidth = 1
    elif clickedInBounds(event.x, event.y, data.passwordInput):
        data.usernameInputWidth = 1
        data.passwordInputWidth = 4
    elif clickedInBounds(event.x, event.y, data.signupButton) and data.username != '' and data.password != '':
        data.mode = 'login'
        data.usernameInputWidth = 1
        data.passwordInputWidth = 1  
        data.userInformation[data.username] = data.password
        data.username = data.password = ''
        pickle.dump(data.userInformation, open('userInfo.p', 'wb'))
    else:
        data.usernameInputWidth = 1
        data.passwordInputWidth = 1  

def signupLeftMouseMoved(event, data):
    pass

def signupLeftMouseReleased(event, data):
    pass

def editingKeyPressed(event, data):
    # if event.keysym == 't':
    #     data.elementsPlaced[data.currentScreen] = 'fuck'
    for element in data.elementsPlaced[data.currentScreen]:
        if element == data.currentElement:
            if event.keysym == 'BackSpace' and data.editedText == None:
                data.elementsPlaced[data.currentScreen].remove(element)
                data.checkFunction = None
                break
    if data.editedText != None:
        print(data.editedText)
        if data.fontInputWidth == 4:
            if event.keysym in string.digits:
                data.currentElement.fontSize += event.keysym
            if event.keysym == 'BackSpace':
                data.currentElement.fontSize = data.currentElement.fontSize[:-1]
            if event.keysym == 'Return':
                data.fontInputWidth = 1
            if data.currentElement.fontSize != '' and int(data.currentElement.fontSize) > 99:
                data.currentElement.fontSize = '99'
        elif data.editedText == data.currentElement:
            if event.keysym in string.printable:
                data.currentElement.text += event.keysym
            if event.keysym == 'BackSpace':
                data.currentElement.text = data.currentElement.text[:-2]
            if event.keysym == 'space':
                data.currentElement.text += ' '
            if event.keysym == 'Return':
                data.currentElement.text += '\n'
            if event.keysym == 'Tab':
                data.currentElement.text += '\t'
            if data.currentElement.type == 'dropdown':
                data.currentElement.shownText = data.currentElement.text.split('\n')[0]
        elif data.editedText == data.currentScreen:
            if event.keysym in string.printable:
                data.screenName[data.currentScreen] += event.keysym
            if event.keysym == 'BackSpace':
                data.screenName[data.currentScreen] = data.screenName[data.currentScreen][:-2]
            if event.keysym == 'space':
                data.screenName[data.currentScreen] += ' '
            if event.keysym == 'Tab':
                data.screenName[data.currentScreen] += '\t'

def handleServerMsg(server, serverMsg):
  server.setblocking(1)
  msg = ""
  while True:
    msg = pickle.loads(server.recv(1024))
    serverMsg.put(msg)

def editingTimerFired(data):
    data.timer += 1
    if data.firstClick != None:
        if data.timer - data.firstClick > 15:
            data.firstClick = None
    if data.editedText != None:
        if data.editedText == data.currentElement:
            data.currentElement.text = data.currentElement.text.replace('|', '')
            data.currentElement.text += '|'
        elif data.editedText == data.currentScreen:
            data.screenName[data.currentScreen] = data.screenName[data.currentScreen].replace('|', '')
            data.screenName[data.currentScreen] += '|'

    msg = pickle.dumps(data.elementsPlaced)
    # msg = "fuck you"
    print("sending: ", msg)
    data.server.send(msg)

    if (serverMsg.qsize() > 0):
          msg = serverMsg.get(False)
          try:
            print("recieved: ", msg)
            if msg.startswith("newPlayer"):
              msg = msg.split()
              newPID = int(msg[1])
              x = int(msg[2])
              y = int(msg[3])
              data.otherStrangers.append([x, y, newPID])
            elif msg.startswith("playerMoved"):
              msg = msg.split()
              PID = int(msg[1])
              dx = int(msg[2])
              dy = int(msg[3])
              for creeper in data.otherStrangers:
                if creeper[2] == PID:
                  creeper[0] += dx * 5
                  creeper[1] += dy * 5
                  break
          except:
            print("failed")
          serverMsg.task_done()


def editingRedrawAll(canvas, data):
    # canvas.create_image(data.width/2, data.height/2 - 30, image=data.phoneImage) #draw the phone
    canvas.create_rectangle(data.width/2 - data.iphone6Res[0]/2, data.height/2 - data.iphone6Res[1]/2 + 10, data.width/2 + data.iphone6Res[0]/2, data.height/2 + data.iphone6Res[1]/2 - 10)
    canvas.create_polygon(910, 10, 940, 25, 910, 40, fill='black')
    canvas.create_text(970, 25, text='Test', font='Helvetica 20')
    chooseColor(canvas, data)
    for elementBox in data.elementBoxes:
        canvas.create_rectangle(elementBox[:-1], fill='white')
        boxType = elementBox[-1]
        drawElementInBox(canvas, data, boxType)
    for screen in data.screenButtons:
        width = 1
        if data.screenSelect == True:
            width = 4
        elif screen[-1] == data.currentScreen:
            width = 4
            scx = data.width/2 # screen center x
            scy = data.height/2 # screen center y
            canvas.create_text(scx, scy + (data.height/2) - 22, text = data.screenName[screen[-1]],font= 'Helvetica 30')
        canvas.create_rectangle(screen[:-1], width=width)
        # drawSmallVersion(canvas, data, screen[-1])
        bcx = (screen[0] + screen[2]) / 2 # box center x
        bcy = (screen[1] + screen[3]) / 2 # box center y
        canvas.create_text(bcx - 20, bcy + 30, text = data.screenName[screen[-1]])
    if data.elementHeld != None:
        data.elementHeld.draw(canvas)
    for element in data.elementsPlaced[data.currentScreen]:
        element.draw(canvas)
        if data.currentElement == element:
            if element.type == 'textBox' or element.type == 'button':
                canvas.create_rectangle(element.left - data.grabberSize, element.top - data.grabberSize, element.left + data.grabberSize, element.top + data.grabberSize, fill= 'white', width=2)
                canvas.create_rectangle(element.left - data.grabberSize, element.bottom - data.grabberSize, element.left + data.grabberSize, element.bottom + data.grabberSize, fill= 'white', width=2)
                canvas.create_rectangle(element.right - data.grabberSize, element.top - data.grabberSize, element.right + data.grabberSize, element.top + data.grabberSize, fill= 'white', width=2)
                canvas.create_rectangle(element.right - data.grabberSize, element.bottom - data.grabberSize, element.right + data.grabberSize, element.bottom + data.grabberSize, fill= 'white', width=2)
            else:
                canvas.create_rectangle(element.left - data.grabberSize, element.y - data.grabberSize, element.left + data.grabberSize, element.y + data.grabberSize, fill= 'white', width=2)
                canvas.create_rectangle(element.right - data.grabberSize, element.y - data.grabberSize, element.right + data.grabberSize, element.y + data.grabberSize, fill= 'white', width=2)
    if data.checkFunction != None:
        functionPicker(canvas, data, data.checkFunction)

    # canvas.create_image(685, 22.5, image=data.clear) #clear icon
    canvas.create_image(765, 22.5, image=data.save) #save icon
    canvas.create_image(845, 22.5, image=data.load) #load icon


    canvas.create_line(0, 50, 1000, 50)
    canvas.create_line(0, 650, 1000, 650) 

def drawElementInBox(canvas, data, boxType):
    if boxType == 'button':
        boxButton = Buttonn(50, 100, 40, 20, 'white', 'button')
        boxButton.draw(canvas)
    elif boxType == 'slider':
        boxSlider = Slider(50, 200, 50, 3, 'white', 10)
        boxSlider.draw(canvas)
    elif boxType == 'textBox':
        boxTextBox = TextBox(50, 300, 40, 20, 'white', "text box")
        boxTextBox.draw(canvas)
    elif boxType == 'dropDown':
        boxDropDown = DropDown(50, 400, 40, 15, 'white', "")
        boxDropDown.draw(canvas)
    elif boxType == 'line tool':
        canvas.create_text(50, 500, text="line tool")
    elif boxType == 'color':
        canvas.create_oval(10, 570, 50, 620, fill="blue")
        canvas.create_oval(45, 570, 85, 620, fill="yellow")
        canvas.create_oval(40, 600, 80, 650, fill="red")

def clickedColor(x, y, colorChoice, data):
    r = 17.5
    cx = (colorChoice[0] + colorChoice[2]) / 2
    cy = (colorChoice[1] + colorChoice[3]) / 2
    dist = math.sqrt((cx - x)**2  + (cy - y)**2)
    if dist <= r:
        data.currentElement.color = colorChoice[-1]
        
def editingLeftMousePressed(event, data):
    for elementBox in data.elementBoxes:
        if clickedInBounds(event.x, event.y, elementBox):
            if elementBox[-1] == 'color':
                data.chooseColor = not data.chooseColor
            data.currentHeld = elementBox[-1]
    if data.chooseColor == True and data.currentElement != None:
        for colorChoice in data.colorChoices:
            clickedColor(event.x, event.y, colorChoice, data)
    for element in data.elementsPlaced[data.currentScreen]:
        # if element.type == 'slider': 
        #     dist = math.sqrt((element.x - event.x)**2  + (element.y - event.y)**2) # make slider clickable in circle
        #     print(dist, element.r)
        #     if dist <= element.r or element.left < event.x < element.right and element.top < event.y < element.bottom:
        #         data.currentElement = element
        if element.left < event.x < element.right and element.top < event.y < element.bottom:
            data.currentElement = element # this element can now be edited
        elif data.width/2 - data.iphone6Res[0]/2 < event.x  and data.height/2 - data.iphone6Res[1]/2  < event.y < data.height/2 + data.iphone6Res[1]/2 :
            if data.editedText != None:
                if data.editedText == data.currentElement:
                    data.currentElement.text = data.currentElement.text.replace('|', '')
            data.currentElement = None
            data.editedText = None
            data.checkFunction = None

    for element in data.elementsPlaced[data.currentScreen]:
        if element == data.currentElement: # prevents multiple elements being edited at once 
            bottomRight = (element.right, element.bottom)
            bottomLeft = (element.left, element.bottom)
            topRight = (element.right, element.top)
            topLeft = (element.left, element.top)
            clickableRadius = 10
            if element.type == 'button' or element.type == 'textBox':
                if bottomRight[0] - clickableRadius < event.x < bottomRight[0] + clickableRadius and bottomRight[1] - clickableRadius < event.y < bottomRight[1] + clickableRadius:
                    data.editArea = 'bottomRight'
                    break
                elif bottomLeft[0] - clickableRadius < event.x < bottomLeft[0] + clickableRadius and bottomLeft[1] - clickableRadius < event.y < bottomLeft[1] + clickableRadius:
                    data.editArea = 'bottomLeft'
                    break
                elif topRight[0] - clickableRadius < event.x < topRight[0] + clickableRadius and topRight[1] - clickableRadius < event.y < topRight[1] + clickableRadius:
                    data.editArea = 'topRight'
                    break
                elif topLeft[0] - clickableRadius < event.x < topLeft[0] + clickableRadius and topLeft[1] - clickableRadius < event.y < topLeft[1] + clickableRadius:
                    data.editArea = 'topLeft'
                    break
                elif element.left < event.x < element.right and element.top < event.y < element.bottom:
                    data.editArea = 'position'
                    data.xDifference = element.right - event.x
                    data.yDifference = element.bottom - event.y
                    break
            else:
                if element.left - clickableRadius < event.x < element.left + clickableRadius and element.y - clickableRadius < event.y < element.y + clickableRadius:
                    data.editArea = 'left'
                    break
                if element.right - clickableRadius < event.x < element.right + clickableRadius and element.y - clickableRadius < event.y < element.y + clickableRadius:
                    data.editArea = 'right'
                    break
                elif element.left < event.x < element.right and element.top < event.y < element.bottom:
                    data.editArea = 'position'
                    data.xDifference = element.right - event.x
                    data.yDifference = element.bottom - event.y
                    break

    if clickedInBounds(event.x, event.y, data.firstBox):
        data.firstBoxWidth = 4
        data.secondBoxWidth = 1
        if data.titleText == 'Button':
            data.screenSelect = not data.screenSelect

    if clickedInBounds(event.x, event.y, data.dropDownOptions):
        data.dropDownOptionsWidth = 4
        if data.currentElement.type == 'dropdown':
            data.editedText = data.currentElement

    elif clickedInBounds(event.x, event.y, data.secondBox):
        data.secondBoxWidth = 4
        data.firstBoxWidth = 1
    else:
        data.firstBoxWidth = 1
        data.secondBoxWidth = 1
    if clickedInBounds(event.x, event.y, data.fontInput):
        data.fontInputWidth = 4
        data.editedText = data.currentElement.fontSize
    else:
        data.fontInputWidth = 1

    if clickedInBounds(event.x, event.y, data.screenText):
        if data.firstClick == None:
            data.firstClick = data.timer
        elif data.firstClick != None:
            data.secondClick = data.timer
        if data.firstClick != None and data.secondClick != None:
            if data.secondClick - data.firstClick <= 15: # must be a short enough time between clicks to be considered a double click
                data.editedText = data.currentScreen
            else:
                data.editedText = None
            data.firstClick = data.secondClick = None

    for element in data.elementsPlaced[data.currentScreen]:
        if element.left < event.x < element.right and element.top < event.y < element.bottom:
            data.checkFunction = element
            if (element.type == 'textBox' or element.type == 'button'):
                if data.firstClick == None:
                    data.firstClick = data.timer
                elif data.firstClick != None:
                    data.secondClick = data.timer
            if data.firstClick != None and data.secondClick != None:
                if data.secondClick - data.firstClick <= 15: # must be a short enough time between clicks to be considered a double click
                    if element.type == 'textBox'or element.type == 'button':
                        data.editedText = element
                else:
                    data.editedText = None
                data.firstClick = data.secondClick = None
            break

    for screen in data.screenButtons:
        if clickedInBounds(event.x, event.y, screen):
            if data.screenSelect == True: # user is prompted to select a screen to link to
                data.screenSelect = False
                data.currentElement.linkedTo = screen[-1]
            elif data.screenSelect == False:
                data.checkFunction = None
                data.currentScreen = screen[-1]
                data.currentElement = None

    if clickedInBounds(event.x, event.y, data.saveBounds):
        pickle.dump(data.elementsPlaced, open('elementsPlaced.p', 'wb'))
    elif clickedInBounds(event.x, event.y, data.loadBounds):
        data.elementsPlaced = pickle.load(open("elementsPlaced.p", "rb"))
    # elif clickedInBounds(event.x, event.y, data.clearBounds):
        # data.clearConfirmation = True
        # data.elementsPlaced = {}
    if 900 < event.x < 1000 and 0 < event.y < 50:
        data.mode = 'testing'

def clickedInBounds(x, y, bounds): # where x and y are the click coordinates and bounds is a set of coordinates representing the clickable area
    if bounds[0] < x < bounds[2] and bounds[1] < y < bounds[3]:
        return True

def chooseColor(canvas, data):
    r = 17.5 # radius of color circle
    numColors = 10
    colors = ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink', 'brown', 'white', 'black']
    i = 0
    yMargin = 10
    xMargin = 90
    if data.chooseColor == True:
        data.colorBox.draw(canvas)
        data.colorBox.x += 50
        if data.colorBox.x + data.colorBox.width > 375:
            data.colorBox.x = 375 - data.colorBox.width
        for row in range(2):
            for col in range(5):
                i += 1
                left = data.colorBox.x - data.colorBox.width
                top = data.colorBox.y - data.colorBox.height
                canvas.create_oval(left + xMargin + col*53, top + yMargin + row*48, left + xMargin + 2*r + col*53, top + yMargin + 2*r + row*48, fill=colors[i-1])
    else:
        data.colorBox.draw(canvas)
        data.colorBox.x -= 50
        if data.colorBox.x + data.colorBox.width < 0:
            data.colorBox.x = -data.colorBox.width
        for row in range(2):
            for col in range(5):
                i += 1
                left = data.colorBox.x - data.colorBox.width
                top = data.colorBox.y - data.colorBox.height
                canvas.create_oval(left + xMargin + col*53, top + yMargin + row*48, left + xMargin + 2*r + col*53, top + yMargin + 2*r + row*48, fill=colors[i-1])

def editingLeftMouseMoved(event, data):
    # drag and drop the buttons
    if data.currentHeld == "button":
        data.elementHeld = Buttonn(event.x, event.y, 40, 20, 'white', 'button')
    elif data.currentHeld == "slider":
        data.elementHeld = Slider(event.x, event.y, 50, 3, 'white', 10)
    elif data.currentHeld == "textBox":
        data.elementHeld = TextBox(event.x, event.y, 40, 20, 'white', "text box")
    elif data.currentHeld == "dropDown":
        data.elementHeld = DropDown(event.x, event.y, 40, 15, 'white', '')
    # elif data.currentHeld == 'lineTool':
    #     data.usingLineTool = True
    for element in data.elementsPlaced[data.currentScreen]:
        if element == data.currentElement: 
            bottomRight = (element.right, element.bottom)
            bottomLeft = (element.left, element.bottom)
            topRight = (element.right, element.top)
            topLeft = (element.left, element.top)
            if data.editArea =='bottomRight':
                element.right = event.x
                element.bottom = event.y
            elif data.editArea == 'bottomLeft':
                element.left = event.x
                element.bottom = event.y
            elif data.editArea == 'topRight':
                element.right = event.x
                element.top = event.y
            elif data.editArea =='topLeft':
                element.left = event.x
                element.top = event.y
            elif data.editArea == 'left':
                element.left = event.x
            elif data.editArea == 'right':
                element.right = event.x
            if element.right - element.left < 10:
                if 'left' in data.editArea.lower():
                    element.left = element.right - 10
                else:
                    element.right = element.left + 10
            if element.bottom - element.top < 10 and element.type != 'slider':
                if 'top' in data.editArea.lower():
                    element.top = element.bottom - 10
                else:
                    element.bottom = element.top + 10

            if data.editArea == 'position':
                width = (element.right - element.left)
                height = (element.bottom - element.top)
                element.right = event.x + data.xDifference
                element.left = event.x - (width - data.xDifference)
                element.bottom = event.y + data.yDifference
                element.top = event.y - (height - data.yDifference)
            if element.type == 'slider':
                element.cx = (element.right + element.left) / 2
                element.cy = (element.top + element.bottom) / 2
            element.x = (element.right + element.left) / 2
            element.y = (element.top + element.bottom) / 2




def editingLeftMouseReleased(event, data):
    if data.elementHeld != None:
        if data.width/2 - data.iphone6Res[0]/2 + data.elementHeld.width < event.x < data.width/2 + data.iphone6Res[0]/2  - data.elementHeld.width and data.height/2 - data.iphone6Res[1]/2  + data.elementHeld.height < event.y < data.height/2 + data.iphone6Res[1]/2  - data.elementHeld.height: # if the object is placed within the screen bounds
            data.elementsPlaced[data.currentScreen].append(data.elementHeld) # this boolean determines whether or not the element is being edited or not
        data.elementHeld = None
        data.currentHeld = None
    data.editArea = None

def editingRightMousePressed(event, data):
    pass

def functionPicker(canvas, data, element):
    firstBox = data.firstBox
    secondBox = data.secondBox
    if element.type == 'button':
        data.titleText = 'Button'
        canvas.create_text(135, 150, text='Button Links to:', anchor=W)
        canvas.create_rectangle(firstBox, width = data.firstBoxWidth)
        if data.currentElement.linkedTo != None:
            canvas.create_text(200, 200, text='Screen %s' % data.currentElement.linkedTo) # want the icon of the linked screen
        canvas.create_rectangle(125, 75, 308, 240)

    elif element.type == 'textBox':
        data.titleText = 'Text Box'
        canvas.create_text(145, 150, text='Font Size', anchor=W)
        canvas.create_rectangle(data.fontInput, width = data.fontInputWidth)
        canvas.create_text(270, 150, text=element.fontSize)
        canvas.create_rectangle(125, 75, 308, 190)

    elif element.type == 'dropdown':
        data.titleText = 'Dropdown Menu'
        canvas.create_text(135, 150, text='Menu options:', anchor=W)
        canvas.create_rectangle(data.dropDownOptions, width = data.dropDownOptionsWidth) # make this fit more options later
        canvas.create_text(140, 165, text=element.text, anchor=NW)
        canvas.create_rectangle(125, 75, 308, 350)

    canvas.create_text(216.5, 100, text=data.titleText, font='Helvetica 17')


def testingMousePressed(event, data):
    pass

def testingKeyPressed(event, data):
    pass

def testingTimerFired(data):
    pass

def testingRedrawAll(canvas, data):
    for element in data.elementsPlaced[data.currentScreen]:
        if element.type == 'dropdown':
            if element.opened == True:
                menuOptions = element.text.split('\n')
                print(menuOptions)
                for i in range(1, len(menuOptions) + 1):
                    height = element.height*2
                    cx = (element.left + element.right)/2
                    cy = ((element.bottom + (i-1)*height) + (element.bottom + i*height)) / 2
                    canvas.create_rectangle(element.left, element.bottom + (i-1)*height, element.right, element.bottom + i*height, fill='white')
                    if menuOptions[i-1] != '|':
                        if '|' in menuOptions[i-1]:
                            menuOptions[i-1] = menuOptions[i-1].replace('|', '')
                        canvas.create_text(cx, cy, text=menuOptions[i-1])
                        optionBoxBounds = [element.left, element.bottom + (i-1)*height, element.right, element.bottom + i*height, menuOptions[i-1]]
                        if optionBoxBounds not in data.optionBoxes[data.currentScreen]:
                            data.optionBoxes[data.currentScreen].append(optionBoxBounds)
        if data.screenTransition == None:
            element.draw(canvas)

    if data.screenTransition != None:
        animateScreen(canvas, data, data.screenTransition)

    canvas.create_image(data.width/2, data.height/2, image=data.phoneImage) #draw the phone
    canvas.create_rectangle(900, 600, 1000, 700, fill = "light blue")
    canvas.create_text(950, 650, text="return to editing")

def animateScreen(canvas, data, screenTransition):
    # newScreen = AnimatedBox(500 + 337.5, 600 + 580.3, 337.5, 580.3, 'white')
    incomingScreenOffset = data.offset
    outgoingScreenOffset = data.offset - 337.5
    canvas.create_line(500 - (337.5)/2 + data.offset, 350 - 580.3, 500 - (337.5)/2 + data.offset, 350 + 580.3)
    for incomingElement in data.elementsPlaced[screenTransition]:
        incomingElement.draw(canvas, incomingScreenOffset)
    for outgoingElement in data.elementsPlaced[data.currentScreen]:
        outgoingElement.draw(canvas, outgoingScreenOffset)
    data.offset -= 25
    if data.offset <= 0:
        data.offset = 0
        data.currentScreen = screenTransition

def testingLeftMousePressed(event, data):
    if 900 < event.x < 1000 and 600 < event.y < 700:
        data.mode = 'editing'
        data.checkFunction = None
        data.screenTransition = None
    for element in data.elementsPlaced[data.currentScreen]:
        if element.type == 'slider':
            dist = math.sqrt((element.cx - event.x)**2  + (element.cy - event.y)**2)
            if dist <= element.r: # clicked within the slider circle
                data.movingCircle = element
            element.opened = False
        elif element.left < event.x < element.right and element.top < event.y < element.bottom: # clicked on element
                if element.type == 'button' and element.linkedTo != None: # the button has been linked to something already
                    data.screenTransition = element.linkedTo
                    data.offset = 337.5
                elif element.type == 'dropdown':
                    element.opened = not element.opened
                    dropDownMenuIndex = data.elementsPlaced[data.currentScreen].index(element)
                    dropDownMenu = data.elementsPlaced[data.currentScreen].pop(dropDownMenuIndex)
                    data.elementsPlaced[data.currentScreen] = data.elementsPlaced[data.currentScreen] + [dropDownMenu] # makes sure that dropdown menu overlaps everything else (drawn last)
        elif element.type == 'dropdown':
            if element.opened == True:
                for screen in data.optionBoxes:
                    print(data.optionBoxes[screen])
                    for optionBox in data.optionBoxes[screen]:
                        if clickedInBounds(event.x, event.y, optionBox):
                            element.shownText = optionBox[-1]
            element.opened = False

def testingLeftMouseMoved(event, data):
    if data.movingCircle != None:
        data.movingCircle.cx = event.x
        if data.movingCircle.cx > data.movingCircle.right:
            data.movingCircle.cx = data.movingCircle.right
        elif data.movingCircle.cx < data.movingCircle.left:
            data.movingCircle.cx = data.movingCircle.left

def testingLeftMouseReleased(event, data):
    data.movingCircle = None

####################################
# use the run function as-is
####################################


def run(width, height, serverMsg=None, server=None):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def leftMousePressedWrapper(event, canvas, data):
        leftMousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def leftMouseReleasedWrapper(event, canvas, data):
        leftMouseReleased(event, data)
        redrawAllWrapper(canvas, data)

    def leftMouseMovedWrapper(event, canvas, data):
        leftMouseMoved(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.server = server
    data.serverMsg = serverMsg
    data.width = width
    data.height = height
    data.timerDelay = 10 # milliseconds
    root = Tk()
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    root.bind("<Button-1>", lambda event: leftMousePressedWrapper(event, canvas, data))
    canvas.bind("<B1-Motion>", lambda event:leftMouseMovedWrapper(event, canvas, data))
    root.bind("<B1-ButtonRelease>", lambda event:leftMouseReleasedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

serverMsg = Queue(100)
start_new_thread(handleServerMsg, (server, serverMsg))

run(1000, 800, serverMsg, server)