class Selector(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height

class Buttonn(Selector):
    pass

class Dropdown(Buttonn):
    pass

class Menu(Buttonn):
    pass

class Text(Selector):
    pass

class TextArea(Selector):
    pass

class TextInput(Selector):
    pass

def clickedOnButton(data):
    pass

def mousePressed(event, data):
    # use event.x and event.y
    if data.mode == "editing":
        editingMousePressed(event,data)
    elif data.mode == "testing":
        testingMousePressed(event,data)

def keyPressed(event, data):
    # use event.x and event.y
    if data.mode == "editing":
        editingKeyPressed(event,data)
    elif data.mode == "testing":
        testingKeyPressed(event,data)

def timerFired(data):
    if data.mode == "editing":
        editingTimerFired(data)
    elif data.mode == "testing":
        testingTimerFired(data)

def redrawAll(canvas, data):
    if data.mode == "editing":
        editingRedrawAll(canvas,data)
    elif data.mode == "testing":
        testingRedrawAll(canvas,data)

def leftMousePressed(event, data):
    if data.mode == "editing":
        editingLeftMousePressed(event,data)
    elif data.mode == "testing":
        testingLeftMousePressed(event,data)

def leftMouseMoved(event, data):
    if data.mode == "editing":
        editingLeftMouseMoved(event,data)
    elif data.mode == "testing":
        testingLeftMouseMoved(event,data)

def leftMouseReleased(event, data):
    if data.mode == "editing":
        editingLeftMouseReleased(event,data)
    elif data.mode == "testing":
        testingLeftMouseReleased(event,data)

def init(data):
    data.width = 1000
    data.height = 700
    data.margin = 10
    data.buttons = []
    data.texts = {}
    data.phoneImage = PhotoImage(file='blankPhone.gif')
    data.phoneImageTesting = PhotoImage(file='blankPhoneTesting.gif')
    data.bcx, data.bcy = 50, 50 # box center coordinates
    data.mode = 'editing'
    data.notification = False
    data.checkFunction = False

def editingMousePressed(event, data):
    pass

def editingKeyPressed(event, data):
    pass

def editingTimerFired(data):
    msg = "%d %d" % (data.bcx, data.bcy)
    # print("sending: ", msg, end="")
    data.server.send(bytes(msg, "UTF-8"))
    ########
    if (serverMsg.qsize() > 0):
      msg = serverMsg.get(False)
      try:
        #print("recieved: ", msg)
        if msg.startswith("newPlayer"):
          msg = msg.split()
          print("sending: ", msg, end="")
          newPID = int(msg[1])
          x = int(msg[2])
          y = int(msg[3])

          width = int(msg[4])
          height = int(msg[5])
          chat = str(msg[6])
          data.otherStrangers.append(Player(x, y, "red", width, height, chat, newPID))
        elif msg.startswith("playerMoved"):
          msg = msg.split()
          #print("sending: ", msg, end="")
          PID = int(msg[1])
          x = int(msg[2])
          y = int(msg[3])
          width = int(msg[4])
          height = int(msg[5])
          chat = str(msg[6])
          for creeper in data.otherStrangers:
            if creeper.ID == PID:
              creeper.x = x
              creeper.y = y
              creeper.width = width
              creeper.height = height
              creeper.chat = chat
              break
      except:
        print("failed")
      serverMsg.task_done()

def editingRedrawAll(canvas, data):
    canvas.create_rectangle(data.margin, data.margin, data.width - data.margin, data.height - data.margin) #draw the border
    canvas.create_image(data.width/2, data.height/2 - 30, image=data.phoneImage) #draw the phone
    canvas.create_rectangle(data.bcx - 20, data.bcy - 20, data.bcx + 20, data.bcy + 20, fill='green') #draw the button
    canvas.create_polygon(475, 625, 525, 650, 475, 675) #play button
    if data.checkFunction == True:
        canvas.create_rectangle(data.bcx - 50, data.bcy + 30, data.bcx + 50, data.bcy +70, fill='light grey')


def mouseMotion(event):
    # print('moving without press')
    pass

def editingLeftMousePressed(event, data):
    if 475 < event.x < 525 and 625 < event.y < 675:
        data.mode = "testing"
    if data.bcx - 20 < event.x < data.bcx + 20 and data.bcy - 20 < event.y < data.bcy + 20 and data.bcx > 400:
        data.checkFunction = True

def editingLeftMouseMoved(event, data):
    # drag and drop the button
    try:
        if data.bcx - 20 < event.x < data.bcx + 20 and data.bcy - 20 < event.y < data.bcy + 20: # have to drag sorta slowly
            data.checkFunction = False
            data.bcx = event.x
            data.bcy = event.y
    except:
        print('crash') # crashes sometimes..

def editingLeftMouseReleased(event, data):
    # if event.x and event.y in phone bounds:
    #     data.buttons.append(Button(event.x, event.y, 40, 40))
    pass

def testingMousePressed(event, data):
    pass

def testingKeyPressed(event, data):
    pass

def testingTimerFired(data):
    pass

def testingRedrawAll(canvas, data):
    canvas.create_rectangle(0, 0, 1000, 700, fill="dark grey")
    canvas.create_image(data.width/2, data.height/2, image=data.phoneImageTesting) #draw the phone
    canvas.create_rectangle(data.bcx - 20, data.bcy - 20, data.bcx + 20, data.bcy + 20, fill='green') #draw the button
    canvas.create_rectangle(900, 600, 1000, 700, fill = "blue")
    canvas.create_text(950, 650, text="return to editing")
    if data.notification == True:
        canvas.create_text(data.width/2, data.height/2, text="Clicked on Button!")

def testingLeftMousePressed(event, data):
    if data.bcx - 20 < event.x < data.bcx + 20 and data.bcy - 20 < event.y < data.bcy + 20:
        data.notification = True
    elif 900 < event.x < 1000 and 600 < event.y < 700:
        data.mode = 'editing'
        data.notification = False

def testingLeftMouseMoved(event, data):
    pass

def testingLeftMouseReleased(event, data):
    pass

####################################
# use the run function as-is
####################################

from tkinter import *

def run(width=300, height=300):
    def redrawAllWrapper(canvas, data):
        canvas.delete(ALL)
        redrawAll(canvas, data)
        canvas.update()    

    def mousePressedWrapper(event, canvas, data):
        mousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def keyPressedWrapper(event, canvas, data):
        keyPressed(event, data)
        redrawAllWrapper(canvas, data)

    def leftMousePressedWrapper(event, canvas, data):
        leftMousePressed(event, data)
        redrawAllWrapper(canvas, data)

    def leftMouseReleasedWrapper(event, canvas, data):
        leftMouseReleased(event, data)
        redrawAllWrapper(canvas, data)

    def leftMouseMovedWrapper(event, canvas, data):
        leftMouseMoved(event, data)
        redrawAllWrapper(canvas, data)

    def timerFiredWrapper(canvas, data):
        timerFired(data)
        redrawAllWrapper(canvas, data)
        # pause, then call timerFired again
        canvas.after(data.timerDelay, timerFiredWrapper, canvas, data)
    # Set up data and call init
    class Struct(object): pass
    data = Struct()
    data.server = server
    data.serverMsg = serverMsg
    data.width = width
    data.height = height
    data.timerDelay = 100 # milliseconds
    root = Tk()
    init(data)
    # create the root and the canvas
    canvas = Canvas(root, width=data.width, height=data.height)
    canvas.pack()
    # set up events
    root.bind("<Button-1>", lambda event:
                            mousePressedWrapper(event, canvas, data))
    root.bind("<Key>", lambda event:
                            keyPressedWrapper(event, canvas, data))
    canvas.bind("<Motion>", mouseMotion)
    root.bind("<Button-1>", lambda event: leftMousePressedWrapper(event, canvas, data))
    canvas.bind("<B1-Motion>", lambda event:leftMouseMovedWrapper(event, canvas, data))
    root.bind("<B1-ButtonRelease>", lambda event:leftMouseReleasedWrapper(event, canvas, data))
    timerFiredWrapper(canvas, data)
    # and launch the app
    root.mainloop()  # blocks until window is closed
    print("bye!")

serverMsg = Queue(100)
start_new_thread(handleServerMsg, (server, serverMsg))

run(1000, 800, serverMsg, server)