from data import *
from flask import Flask, render_template, request, redirect, url_for
from scraper import *
import requests
from lxml import html
users = []
curName = []
users = readUserTxt("users.txt")
print(users)
app = Flask(__name__)
app.debug = True

@app.route("/")
def home():
  return render_template("index.html")

@app.route("/logout")
def logout():
  curName = []
  return render_template("index.html")

@app.route("/returnHome")
def returnHome():
  user = curName[-1]
  return render_template("homeScreen.html",user = user)

@app.route("/gotoImportCSV")
def gotoImportCSV():
  return render_template("importData.html")

@app.route("/login", methods = ["POST"])
def login():
  check = request.form["userName"]
  name = None
  for user in users:
    if user.name == check:
      check = True
      name = user.name
      curName.append(user.name)
  if check == True:
    return render_template("homeScreen.html", user=name)
  else:
    return render_template("index.html",message = "User Not Found! Please Register")

import csv
@app.route("/newData", methods = ["POST"])
def newData():
  newData = str(request.files["data"].read())
  newData = arranged(newData)
  print(newData)
  finalData = []
  for i in range(len(newData)):
    done = False
    if type(newData[i]) == str:
      if "\\r" in newData[i]:
        newData[i] = newData[i].replace("reps","")
        split1 = newData[i].index("\\r")
        split2 = newData[i].index("r")
        finalData.append(newData[i][:split1])
        finalData.append(newData[i][split2+1:])
        done = True
    if done == False:
      try:
        finalData[i] = int(finalData[i])
      except:
       pass
      finalData.append(newData[i])
  finalData = finalData[1:]
  print("final",finalData)
  newData = finalData
  for user in users:
    if user.getName() == curName[-1]:
      date = None ; lift = None ; weight = None; sets = None ; reps = None; count = 0
      for i in range(len(newData)):
        if i == len(newData)-1:
          print(lift,weight,sets,reps)
          if lift == "benchpress":
            user.addBench(date,weight,sets,reps)
          elif lift == "squat":
            user.addSquat(date,weight,sets,reps)
          elif lift == "deadlift":
            user.addDeadlift(date,weight,sets,reps)
        elif i == 0:
          date = newData[i]
        elif i % 5 == 0:
          if lift == "benchpress":
            user.addBench(date,weight,sets,reps)
          elif lift == "squat":
            print("FUCK")
            user.addSquat(date,weight,sets,reps)
          elif lift == "deadlift":
            user.addDeadlift(date,weight,sets,reps)
          date = newData[i]
        elif type(newData[i]) == str:
          lift = newData[i].lower()
          lift = lift.replace(" ","")
        elif count == 0:
          weight = int(newData[i])
          count +=1 
        elif count == 1:
          sets = int(newData[i])
          count += 1
        elif count == 2:
          reps = int(newData[i])
          count = 0
  createUsers(users)
  return render_template("homeScreen.html")
  
@app.route("/register", methods = ["POST"])
def register():
  return render_template("register.html")

@app.route("/newUser", methods = ["POST"])
def createUser():
  name = request.form["name"]
  gender = request.form["gender"]
  users.append(User(name,gender))
  curName.append(name)
  message = "Please Log In Now! "
  return render_template("index.html",message=message)

@app.route("/newEntry", methods = ["POST"])
def createEntry():
  movement = request.form["movement"]
  date = request.form["date"]
  weight = int(request.form["weight"])
  sets = int(request.form["sets"])
  reps = int(request.form["reps"])
  for user in users:
    if user.getName() == curName[-1]:
      if movement == "1":
        user.addBench(date,weight,sets,reps)
      elif movement == "2":
        user.addSquat(date,weight,sets,reps)
      else:
        user.addDeadlift(date,weight,sets,reps)
      createUsers(users)
      return redirect(url_for("loadEntries"))     

@app.route("/loadEntries")
def loadEntries(): 
  dateList = []
  weight = []
  setsReps = []
  for user in users:
    if user.getName() == curName[-1]:
      data = user.getTopFive("benchPress")
      for key in data:
        date = key
        weightVar = data[date][0]
        setsRepsVar = str(data[date][1]) + " x " + str(data[date][2])
        dateList.append(date)
        weight.append(weightVar)
        setsReps.append(setsRepsVar)
      return render_template("stats.html",dateList=dateList,weight=weight,setsReps=setsReps)
@app.route("/loadEntriesSquat")
def loadEntriesSquat(): 
  dateList = []
  weight = []
  setsReps = []
  for user in users:
    if user.getName() == curName[-1]:
      data = user.getTopFive("squat")
      for key in data:
        date = key
        weightVar = data[date][0]
        setsRepsVar = str(data[date][1]) + " x " + str(data[date][2])
        dateList.append(date)
        weight.append(weightVar)
        setsReps.append(setsRepsVar)
      return render_template("stats.html",dateList=dateList,weight=weight,setsReps=setsReps)
@app.route("/loadEntriesDeadlift")
def loadEntriesDeadlift(): 
  dateList = []
  weight = []
  setsReps = []
  for user in users:
    if user.getName() == curName[-1]:
      data = user.getTopFive("deadlift")
      for key in data:
        date = key
        weightVar = data[date][0]
        setsRepsVar = str(data[date][1]) + " x " + str(data[date][2])
        dateList.append(date)
        weight.append(weightVar)
        setsReps.append(setsRepsVar)
      return render_template("stats.html",dateList=dateList,weight=weight,setsReps=setsReps)

@app.route("/inputWeight")
def inputWeight():
  return render_template("InputWeight.html")

@app.route("/learnBody")
def learnBody():
  return render_template("body.html")

##################################
####### All Body Page Reroutes ###
##################################

#gets scraped images and returns them to the pages they are displayed on
def getScrapedEvens(infoDict):
  title = []
  imgURL = []
  imgURLodds = []
  count = 0
  for name in infoDict:
    title.append(name)
    for pic in infoDict[name]:
      if count % 2 == 0:
        imgURL.append(pic)
      else:
        imgURLodds.append(pic)
      count +=1 
  return [title,imgURL,imgURLodds]

@app.route("/chest")
def chest():
  infoDict = getChest()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("chest.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/shoulder")
def shoulder():
  infoDict = getShoulder()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("shoulder.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/bicep")
def bicep():
  infoDict = getBicep()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("bicep.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/abs")
def abs():
  infoDict = getAbs()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("abs.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/forearm")
def forearm():
  infoDict = getForearms()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("forearms.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/quad")
def quad():
  infoDict = getQuads()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("quad.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)


@app.route("/trapMiddle")
def trapMiddle():
  infoDict = getTrapsMiddle()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("trapMiddle.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/back")
def back():
  infoDict = getBack()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("back.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/hamstring")
def hamstring():
  infoDict = getHamstrings()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("hamstring.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/calves")
def calves():
  infoDict = getCalves()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("calves.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/glutes")
def glutes():
  infoDict = getGlutes()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("glute.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/lowBack")
def lowBack():
  infoDict = getLowBack()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("lowBack.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

@app.route("/tricep")
def tricep():
  infoDict = getTricep()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("tricep.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)
@app.route("/traps")
def traps():
  infoDict = getTraps()
  infoDict = getScrapedEvens(infoDict)
  title = infoDict[0]
  imgURL = infoDict[1]
  imgURLodds = infoDict[2]
  return render_template("traps.html",title = title, imgURL = imgURL, imgURLodds = imgURLodds)

if __name__ == "__main__":
  app.run()